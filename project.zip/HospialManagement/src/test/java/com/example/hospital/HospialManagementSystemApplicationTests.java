package com.example.hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospialManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
