package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospialManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospialManagementApplication.class, args);
	}

}
