package com.example.jdbcconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ExampleForJDBCConnection {

	public static void main(String[] args) {
		//JDBC URL, USERNAME AND PASSWORD OF MYSQL SERVER
		String jdbcurl = "jdbc:mysql://localhost:3306/kle";
		String username = "root";
		String password = "root";
		
		try {
			
			//Establish a connection
			
			Connection connect = DriverManager.getConnection(jdbcurl, username, password);
			
			System.out.println("Connection Successfull");
			
			connect.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
