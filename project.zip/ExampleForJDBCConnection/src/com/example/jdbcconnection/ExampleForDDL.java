package com.example.jdbcconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ExampleForDDL {

	public static void main(String[] args) {
		//JDBC URL, USERNAME AND PASSWORD OF MYSQL SERVER
		String jdbcurl = "jdbc:mysql://localhost:3306/kle";
		String username = "root";
		String password = "root";
				
			try(Connection connect = DriverManager
					.getConnection(jdbcurl, username, password);
					
					Statement s = connect.createStatement())
			
			{	/*
				//FOR TABLE CREATION
				String createTable = "CREATE TABLE users(id INT primary key, name VARCHAR(200))";
				s.execute(createTable);
				System.out.println("Table created successfully");
				
				//FOR TABLE ALTERATION
				String alterTable = "ALTER TABLE users ADD COLUMN email VARCHAR(20)";
				s.execute(alterTable);
				System.out.println("Table altered successfully");
				
				//FOR INSERTION
				String insertData = "INSERT INTO users(id, name, email) VALUES(1, 'Vanisha', 'vanisha@gmail.com'), (2, 'Sahana', 'sahana@gmail.com')";
				s.executeUpdate(insertData);
				System.out.println("Record inserted successfully");

				//FOR DROP TABLE
				String DropTable = "Drop Table users";
				s.execute(DropTable);
				System.out.println("Table dropped successfully");	
				*/
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
	}
}