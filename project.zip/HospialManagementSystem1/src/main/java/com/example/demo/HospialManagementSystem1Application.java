package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospialManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(HospialManagementSystem1Application.class, args);
	}

}
